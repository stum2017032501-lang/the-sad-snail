extends CharacterBody2D

func _physics_process(delta):
	var input_direction = Vector2.ZERO
	
	if Input.is_key_pressed(KEY_A):
		input_direction.x -= 1
	if Input.is_key_pressed(KEY_D):
		input_direction.x += 1
	if Input.is_key_pressed(KEY_W):
		input_direction.y -= 1
	if Input.is_key_pressed(KEY_S):
		input_direction.y += 1
		
	input_direction = input_direction.normalized()
	velocity = input_direction * 400
	move_and_slide()
